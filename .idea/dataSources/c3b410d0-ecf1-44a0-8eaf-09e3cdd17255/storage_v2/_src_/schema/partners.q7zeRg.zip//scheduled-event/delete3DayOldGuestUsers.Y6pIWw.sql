create definer = root@localhost event delete3DayOldGuestUsers on schedule
    every '1' DAY
        starts '2021-02-27 00:00:00'
    on completion preserve
    disable
    do
    BEGIN
	DELETE FROM users
    WHERE level = 0
    AND datediff(now(), created_date)>2;
    
END;

