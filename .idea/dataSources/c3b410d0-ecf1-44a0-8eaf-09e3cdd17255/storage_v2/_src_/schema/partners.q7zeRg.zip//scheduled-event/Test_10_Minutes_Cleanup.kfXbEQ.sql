create definer = root@localhost event Test_10_Minutes_Cleanup on schedule
    every '10' MINUTE
        starts '2021-02-27 00:00:00'
    on completion preserve
    disable
    do
    BEGIN
	DELETE FROM users
    WHERE level = 0;
END;

